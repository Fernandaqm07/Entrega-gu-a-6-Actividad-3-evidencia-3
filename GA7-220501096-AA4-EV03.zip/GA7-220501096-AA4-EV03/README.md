# Proyecto de Cotización de Gráficas Boyacá

## Descripción
Frontend del proyecto formativo desarrollado con React JS. Permite a los clientes cotizar productos como banners, libretas y tarjetas.

## Tecnologías utilizadas
- React JS
- JavaScript (ES6+)
- CSS / TailwindCSS
- Git y GitHub

## Instrucciones para ejecutar
1. Clona el repositorio
2. Ejecuta `npm install`
3. Ejecuta `npm run dev` para desarrollo

## Repositorio
[Enlace al repositorio aquí]
