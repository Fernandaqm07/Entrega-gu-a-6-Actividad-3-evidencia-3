import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
// Puedes importar aquí otras páginas o componentes, como Home o FormCotizacion

function App() {
  return (
    <div>
      <Header />

      <main style={{ padding: '20px' }}>
        <h2>Bienvenido al sistema de cotización</h2>
        <p>Por favor, seleccione los servicios para generar su cotización.</p>
        {/* Aquí puedes insertar <FormCotizacion /> o tus páginas como <Home /> */}
      </main>

      <Footer />
    </div>
  );
}

export default App;
