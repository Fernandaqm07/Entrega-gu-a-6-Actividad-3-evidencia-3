import React from 'react';

const Header = () => {
  return (
    <header style={styles.header}>
      <h1 style={styles.title}>Cotización Gráficas Boyacá</h1>
      <nav>
        <a href="#" style={styles.link}>Inicio</a>
        <a href="#" style={styles.link}>Servicios</a>
        <a href="#" style={styles.link}>Contacto</a>
      </nav>
    </header>
  );
};

const styles = {
  header: {
    backgroundColor: '#003366',
    padding: '15px',
    color: '#fff',
    textAlign: 'center'
  },
  title: {
    marginBottom: '10px'
  },
  link: {
    margin: '0 10px',
    color: '#fff',
    textDecoration: 'none'
  }
};

export default Header;
npm