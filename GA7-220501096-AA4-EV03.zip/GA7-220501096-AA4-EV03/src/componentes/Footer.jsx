import React from 'react';

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <p>© {new Date().getFullYear()} Gráficas Boyacá. Todos los derechos reservados.</p>
    </footer>
  );
};

const styles = {
  footer: {
    backgroundColor: '#003366',
    padding: '15px',
    color: '#fff',
    textAlign: 'center',
    position: 'relative',
    bottom: 0,
    width: '100%'
  }
};

export default Footer;

